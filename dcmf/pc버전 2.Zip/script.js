// 페이지 이동
function goToPage(pageId) {
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));

    const targetPage = document.getElementById(pageId);
    if (targetPage) {
        targetPage.classList.add('active');
        window.scrollTo(0, 0);
        // 스크롤이 있는 페이지인 경우 최상단으로
        const scrollArea = targetPage.querySelector('.scroll-container');
        if (scrollArea) scrollArea.scrollTop = 0;
    }
}

// 비밀번호 체크
function checkPassword() {
    const input = document.getElementById('password-input').value;
    const correctPassword = "1234abcd";

    if (input === correctPassword) {
        goToPage('page1'); // 성공 시 첫 페이지로
    } else {
        alert("Chave de acesso incorreta. Verifique a \nchave digitada.");
        document.getElementById('password-input').value = "";
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // 1. 보안: 소스 보기 및 복사 방지
    document.addEventListener('keydown', (e) => {
        // F12 방지
        if (e.key === "F12") {
            e.preventDefault();
            return false;
        }
        // Ctrl+U, I, C, V, S 방지
        if (e.ctrlKey && ['u', 'i', 'c', 'v', 's'].includes(e.key.toLowerCase())) {
            e.preventDefault();
            return false;
        }
    });

    // 2. 엔터키로 로그인 실행
    const pwInput = document.getElementById('password-input');
    if (pwInput) {
        pwInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') checkPassword();
        });
    }

    // 3. 슬라이더 로직
    const slider = document.getElementById('slider');
    const dots = document.querySelectorAll('.dot');
    if (slider) {
        slider.addEventListener('scroll', () => {
            const index = Math.round(slider.scrollLeft / slider.clientWidth);
            dots.forEach((dot, i) => {
                if (i === index) dot.classList.add('active');
                else dot.classList.remove('active');
            });
        });
        
        let startX;
        slider.addEventListener('touchstart', (e) => { startX = e.touches[0].pageX; }, {passive: true});
        slider.addEventListener('touchend', (e) => {
            let endX = e.changedTouches[0].pageX;
            let diff = startX - endX;
            if (Math.abs(diff) > 30) {
                if (diff > 0) slider.scrollBy({ left: 1080, behavior: 'smooth' });
                else slider.scrollBy({ left: -1080, behavior: 'smooth' });
            }
        }, {passive: true});
    }

    // 4. 모바일 확대/축소 방지
    document.addEventListener('touchstart', (e) => {
        if (e.touches.length > 1) e.preventDefault();
    }, { passive: false });
});