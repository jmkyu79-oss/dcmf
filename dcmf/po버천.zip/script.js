function goToPage(pageId) {
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));

    const targetPage = document.getElementById(pageId);
    if (targetPage) {
        targetPage.classList.add('active');
        window.scrollTo(0, 0);
        const scrollArea = targetPage.querySelector('.scroll-container');
        if (scrollArea) scrollArea.scrollTop = 0;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const slider = document.getElementById('slider');
    const dots = document.querySelectorAll('.dot');

    if (slider) {
        slider.addEventListener('scroll', () => {
            const index = Math.round(slider.scrollLeft / slider.clientWidth);
            dots.forEach((dot, i) => {
                if (i === index) dot.classList.add('active');
                else dot.classList.remove('active');
            });
        });

        let startX;
        slider.addEventListener('touchstart', (e) => { startX = e.touches[0].pageX; }, {passive: true});
        slider.addEventListener('touchend', (e) => {
            let endX = e.changedTouches[0].pageX;
            let diff = startX - endX;
            if (Math.abs(diff) > 30) {
                if (diff > 0) slider.scrollBy({ left: 1080, behavior: 'smooth' });
                else slider.scrollBy({ left: -1080, behavior: 'smooth' });
            }
        }, {passive: true});
    }

    // 확대/축소 방지 로직
    document.addEventListener('touchstart', (e) => {
        if (e.touches.length > 1) e.preventDefault();
    }, { passive: false });

    let lastTouchEnd = 0;
    document.addEventListener('touchend', (e) => {
        const now = (new Date()).getTime();
        if (now - lastTouchEnd <= 300) e.preventDefault();
        lastTouchEnd = now;
    }, false);

    document.addEventListener('wheel', (e) => {
        if (e.ctrlKey) e.preventDefault();
    }, { passive: false });

    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && ['+', '-', '=', '0'].includes(e.key)) e.preventDefault();
    });
});